This repository gives the implementation of our work on CIFAR-10/100 datasets.

Requirements:
Python 3.6
numpy 1.19
Pytorch 1.5
torchvision 0.6

You need to download CIFAR-10/100 datasets to './data/', then run the following demos:

python main.py  --dataset cifar10 --seed 101 --batch-size=512 --arch resnet32 --method ce
python main.py  --dataset cifar10 --seed 101 --batch-size=512 --arch resnet32 --method ls --epsilon 0.05

python main.py  --dataset cifar100 --seed 101 --batch-size=512 --arch resnet32 --method ce
python main.py  --dataset cifar100 --seed 101 --batch-size=512 --arch resnet32 --method ls --epsilon 0.09

You will see the ECE results with Temperature Scaling in the last 10 epochs. Have fun!